import React from 'react';
import Sidebar from './components/Sidebar';
import OrganicSphere from './components/OrganicSphere';
import ReservationsView from './components/ReservationsView';

function App() {
  return (
    <div className="flex min-h-screen bg-gray-50 font-[-apple-system,BlinkMacSystemFont,'SF Pro Display','SF Pro Text',system-ui]">
      <Sidebar />
      <main className="flex-1">
        <ReservationsView />
      </main>
    </div>
  );
}

export default App;